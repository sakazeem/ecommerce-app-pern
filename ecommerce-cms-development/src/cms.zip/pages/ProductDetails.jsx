import {
	Badge,
	Pagination,
	Table,
	TableCell,
	TableContainer,
	TableFooter,
	TableHeader,
} from "@windmill/react-ui";
import React, { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router";
//internal import

import useAsync from "@/hooks/useAsync";
import useFilter from "@/hooks/useFilter";
import useProductSubmit from "@/hooks/useProductSubmit";
import useToggleDrawer from "@/hooks/useToggleDrawer";
import ProductServices from "@/services/ProductServices";
import useUtilsFunction from "@/hooks/useUtilsFunction";
import AttributeList from "@/components/attributeOld/AttributeList";
import MainDrawer from "@/components/drawer/MainDrawer";
import ProductDrawer from "@/components/drawer/ProductDrawer";
import Loading from "@/components/preloader/Loading";
import PageTitle from "@/components/Typography/PageTitle";
import { SidebarContext } from "@/context/SidebarContext";

const ProductDetails = () => {
	const { id } = useParams();
	const { t } = useTranslation();
	const { handleUpdate } = useToggleDrawer();
	const { attribue } = useProductSubmit(id);
	const [variantTitle, setVariantTitle] = useState([]);
	const { lang } = useContext(SidebarContext);

	const { data, loading } = useAsync(() => ProductServices.getProductById(id));

	const { currency, showingTranslateValue, getNumberTwo } = useUtilsFunction();

	const { handleChangePage, totalResults, resultsPerPage, dataTable } =
		useFilter(data?.variants);
	// console.log('data',data)

	useEffect(() => {
		if (!loading) {
			const res = Object.keys(Object.assign({}, ...data?.variants));

			const varTitle = attribue?.filter((att) =>
				// res.includes(att.title.replace(/[^a-zA-Z0-9]/g, ''))
				res.includes(att.id),
			);

			setVariantTitle(varTitle);
		}
	}, [attribue, data?.variants, loading, lang]);

	console.log("product", data);

	return (
		<>
			<MainDrawer product>
				<ProductDrawer id={id} />
			</MainDrawer>

			<PageTitle>{t("ProductDetails")}</PageTitle>
			{loading ? (
				<Loading loading={loading} />
			) : (
				<div className="inline-block overflow-y-auto h-full align-middle transition-all transform">
					<div className="flex flex-col lg:flex-row md:flex-row w-full overflow-hidden">
						<div className="flex-shrink-0 flex items-center justify-center h-auto">
							{data?.image[0] ? (
								<img src={data?.image[0]} alt="product" className="h-64 w-64" />
							) : (
								<img
									src="https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png"
									alt="product"
								/>
							)}
						</div>
						<div className="w-full flex flex-col p-5 md:p-8 text-left">
							<div className="mb-5 block ">
								<div className="font-serif font-semibold py-1 text-sm">
									<p className="text-sm text-customGray-500 pr-4">
										{t("Status")}:{" "}
										{data.status === "show" ? (
											<span className="text-customTeal-400">
												{t("ThisProductShowing")}
											</span>
										) : (
											<span className="text-customRed-400">
												{t("ThisProductHidden")}
											</span>
										)}
									</p>
								</div>
								<h2 className="text-heading text-lg md:text-xl lg:text-2xl font-semibold font-serif dark:text-customGray-400">
									{showingTranslateValue(data?.title)}
								</h2>
								<p className="uppercase font-serif font-medium text-customGray-500 dark:text-customGray-400 text-sm">
									{t("Sku")} :{" "}
									<span className="font-bold text-customGray-500 dark:text-customGray-500">
										{/* {data?.id !== undefined && data?.id.substring(18, 24)} */}
										{data?.sku}
									</span>
								</p>
							</div>
							<div className="font-serif product-price font-bold dark:text-customGray-400">
								<span className="inline-block text-2xl">
									{currency}
									{getNumberTwo(data?.prices?.price)}
									{data?.prices?.discount >= 1 && (
										<del className="text-customGray-400 dark:text-customGray-500 text-lg pl-2">
											{currency}
											{getNumberTwo(data?.prices?.originalPrice)}
										</del>
									)}
								</span>
							</div>
							<div className="mb-3">
								{data?.stock <= 0 ? (
									<Badge type="danger">
										<span className="font-bold">{t("StockOut")}</span>{" "}
									</Badge>
								) : (
									<Badge type="success">
										{" "}
										<span className="font-bold">{t("InStock")}</span>
									</Badge>
								)}
								<span className="text-sm text-customGray-500 dark:text-customGray-400 font-medium pl-4">
									{t("Quantity")}: {data?.stock}
								</span>
							</div>
							<p className="text-sm leading-6 text-customGray-500 dark:text-customGray-400 md:leading-7">
								{showingTranslateValue(data?.description)}
							</p>
							<div className="flex flex-col mt-4">
								<p className="font-serif font-semibold py-1 text-customGray-500 text-sm">
									<span className="text-customGray-700 dark:text-customGray-400">
										{t("Category")}:{" "}
									</span>{" "}
									{showingTranslateValue(data?.category?.name)}
								</p>
								<div className="flex flex-row">
									{JSON.parse(data?.tag).map((t, i) => (
										<span
											key={i + 1}
											className="bg-customGray-200 mr-2 border-0 text-customGray-500 rounded-full inline-flex items-center justify-center px-2 py-1 text-xs font-semibold font-serif mt-2 dark:bg-customGray-700 dark:text-customGray-300">
											{t}
										</span>
									))}
								</div>
							</div>
							<div className="mt-6">
								<button
									onClick={() => handleUpdate(id)}
									className="cursor-pointer leading-5 transition-colors duration-150 font-medium text-sm focus:outline-none px-5 py-2 rounded-md text-customWhite bg-customTeal-500 border border-transparent active:bg-customTeal-600 hover:bg-customTeal-600 ">
									{t("EditProduct")}
								</button>
							</div>
						</div>
					</div>
				</div>
			)}
			{data?.isCombination && variantTitle?.length > 0 && !loading && (
				<>
					<PageTitle>{t("ProductVariantList")}</PageTitle>
					<TableContainer className="mb-8 rounded-b-lg">
						<Table>
							<TableHeader>
								<tr>
									<TableCell>{t("SR")}</TableCell>
									<TableCell>{t("Image")}</TableCell>
									<TableCell>{t("Combination")}</TableCell>
									<TableCell>{t("Sku")}</TableCell>
									<TableCell>{t("Barcode")}</TableCell>
									<TableCell>{t("OrginalPrice")}</TableCell>
									<TableCell>{t("SalePrice")}</TableCell>
									<TableCell>{t("Quantity")}</TableCell>
								</tr>
							</TableHeader>
							<AttributeList
								lang={lang}
								variants={dataTable}
								currency={currency}
								variantTitle={variantTitle}
							/>
						</Table>
						<TableFooter>
							<Pagination
								totalResults={totalResults}
								resultsPerPage={resultsPerPage}
								onChange={handleChangePage}
								label="Product Page Navigation"
							/>
						</TableFooter>
					</TableContainer>
				</>
			)}
		</>
	);
};

export default ProductDetails;
