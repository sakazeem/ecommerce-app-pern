import { TableBody, TableCell, TableRow } from "@windmill/react-ui";
import dayjs from "dayjs";
import { t } from "i18next";
import React from "react";
import { FiZoomIn } from "react-icons/fi";
import { Link } from "react-router-dom";

//internal import

import MainDrawer from "@/components/drawer/MainDrawer";
import DeleteModal from "@/components/modal/DeleteModal";
import useToggleDrawer from "@/hooks/useToggleDrawer";
import Tooltip from "@/components/tooltip/Tooltip";
import CustomerDrawer from "@/components/drawer/CustomerDrawer";
import EditDeleteButton from "@/components/table/EditDeleteButton";

// internal imports

const CustomerTable = ({ customers }) => {
	const { title, serviceId, handleModalOpen, handleUpdate } = useToggleDrawer();

	return (
		<>
			<DeleteModal id={serviceId} title={title} />

			<MainDrawer>
				<CustomerDrawer id={serviceId} />
			</MainDrawer>

			<TableBody>
				{customers?.map((user) => (
					<TableRow key={user.id}>
						<TableCell>
							<span className="font-semibold uppercase text-xs">
								{" "}
								{user?.id?.substring(20, 24)}
							</span>
						</TableCell>
						<TableCell>
							<span className="text-sm">
								{dayjs(user.createdAt).format("MMM D, YYYY")}
							</span>
						</TableCell>
						<TableCell>
							<span className="text-sm">{user.name}</span>
						</TableCell>
						<TableCell>
							<span className="text-sm">{user.email}</span>{" "}
						</TableCell>
						<TableCell>
							<span className="text-sm font-medium">{user.phone}</span>
						</TableCell>

						<TableCell>
							<div className="flex justify-end text-right">
								<div className="p-2 cursor-pointer text-customGray-400 hover:text-customTeal-600">
									{" "}
									<Link to={`/customer-order/${user.id}`}>
										<Tooltip
											id="view"
											Icon={FiZoomIn}
											title={t("ViewOrder")}
											bgColor="#34D399"
										/>
									</Link>
								</div>

								<EditDeleteButton
									title={user.name}
									id={user.id}
									handleUpdate={handleUpdate}
									handleModalOpen={handleModalOpen}
								/>
							</div>
						</TableCell>
					</TableRow>
				))}
			</TableBody>
		</>
	);
};

export default CustomerTable;
