import ReactTagInput from "@pathofdev/react-tag-input";
import {
	Button,
	Input,
	TableCell,
	TableContainer,
	TableHeader,
	Textarea,
	Table,
} from "@windmill/react-ui";
import Multiselect from "multiselect-react-dropdown";
import React from "react";
import { Scrollbars } from "react-custom-scrollbars-2";
import { MultiSelect } from "react-multi-select-component";
import { Modal } from "react-responsive-modal";
import "react-responsive-modal/styles.css";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { FiX } from "react-icons/fi";

//internal import

import Title from "@/components/form/others/Title";
import Error from "@/components/form/others/Error";
import InputArea from "@/components/form/input/InputArea";
import useUtilsFunction from "@/hooks/useUtilsFunction";
import LabelArea from "@/components/form/selectOption/LabelArea";
import DrawerButton from "@/components/form/button/DrawerButton";
import InputValue from "@/components/form/input/InputValue";
import useProductSubmit from "@/hooks/useProductSubmit";
import ActiveButton from "@/components/form/button/ActiveButton";
import InputValueFive from "@/components/form/input/InputValueFive";
import Uploader from "@/components/image-uploader/Uploader";
import ParentCategory from "@/components/category/ParentCategory";
import UploaderThree from "@/components/image-uploader/UploaderThree";
import AttributeOptionTwo from "@/components/attributeOld/AttributeOptionTwo";
import AttributeListTable from "@/components/attributeOld/AttributeListTable";
import SwitchToggleForCombination from "@/components/form/switch/SwitchToggleForCombination";

//internal import

const ProductDrawer = ({ id }) => {
	const { t } = useTranslation();

	const {
		tag,
		setTag,
		values,
		language,
		register,
		onSubmit,
		errors,
		slug,
		openModal,
		attribue,
		setValues,
		variants,
		imageUrl,
		setImageUrl,
		handleSubmit,
		isCombination,
		variantTitle,
		attributes,
		attTitle,
		handleAddAtt,
		// productId,
		onCloseModal,
		isBulkUpdate,
		globalSetting,
		isSubmitting,
		tapValue,
		setTapValue,
		resetRefTwo,
		handleSkuBarcode,
		handleProductTap,
		selectedCategory,
		setSelectedCategory,
		setDefaultCategory,
		defaultCategory,
		handleProductSlug,
		handleSelectLanguage,
		handleIsCombination,
		handleEditVariant,
		handleRemoveVariant,
		handleClearVariant,
		handleQuantityPrice,
		handleSelectImage,
		handleSelectInlineImage,
		handleGenerateCombination,
	} = useProductSubmit(id);

	const { currency, showingTranslateValue } = useUtilsFunction();

	return (
		<>
			<Modal
				open={openModal}
				onClose={onCloseModal}
				center
				closeIcon={
					<div className="absolute top-0 right-0 text-customRed-500  active:outline-none text-xl border-0">
						<FiX className="text-3xl" />
					</div>
				}>
				<div className="cursor-pointer">
					<UploaderThree
						imageUrl={imageUrl}
						setImageUrl={setImageUrl}
						handleSelectImage={handleSelectImage}
					/>
				</div>
			</Modal>

			<div className="w-full relative p-6 border-b border-customGray-100 bg-customGray-50 dark:border-customGray-700 dark:bg-customGray-800 dark:text-customGray-300">
				{id ? (
					<Title
						register={register}
						handleSelectLanguage={handleSelectLanguage}
						title={t("UpdateProduct")}
						description={t("UpdateProductDescription")}
					/>
				) : (
					<Title
						register={register}
						handleSelectLanguage={handleSelectLanguage}
						title={t("DrawerAddProduct")}
						description={t("AddProductDescription")}
					/>
				)}
			</div>

			<div className="text-sm font-medium text-center text-customGray-500 border-b border-customGray-200 dark:text-customGray-400 dark:border-customGray-600 dark:bg-customGray-700">
				<SwitchToggleForCombination
					product
					handleProcess={handleIsCombination}
					processOption={isCombination}
				/>

				<ul className="flex flex-wrap -mb-px">
					<li className="mr-2">
						<ActiveButton
							tapValue={tapValue}
							activeValue="Basic Info"
							handleProductTap={handleProductTap}
						/>
					</li>

					{isCombination && (
						<li className="mr-2">
							<ActiveButton
								tapValue={tapValue}
								activeValue="Combination"
								handleProductTap={handleProductTap}
							/>
						</li>
					)}
				</ul>
			</div>

			<Scrollbars className="track-horizontal thumb-horizontal w-full md:w-7/12 lg:w-8/12 xl:w-8/12 relative dark:bg-customGray-700 dark:text-customGray-200">
				<form onSubmit={handleSubmit(onSubmit)} className="block" id="block">
					{tapValue === "Basic Info" && (
						<div className="px-6 pt-8 flex-grow w-full h-full max-h-full pb-40 md:pb-32 lg:pb-32 xl:pb-32">
							{/* <div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
                <LabelArea label={t("ProductID")} />
                <div className="col-span-8 sm:col-span-4">{productId}</div>
              </div> */}
							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductTitleName")} />
								<div className="col-span-8 sm:col-span-4">
									<Input
										{...register(`title`, {
											required: "TItle is required!",
										})}
										name="title"
										type="text"
										placeholder={t("ProductTitleName")}
										onBlur={(e) => handleProductSlug(e.target.value)}
									/>
									<Error errorName={errors.title} />
								</div>
							</div>
							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductDescription")} />
								<div className="col-span-8 sm:col-span-4">
									<Textarea
										className="border text-sm  block w-full bg-customGray-100 border-customGray-200"
										{...register("description", {
											required: false,
										})}
										name="description"
										placeholder={t("ProductDescription")}
										rows="4"
										spellCheck="false"
									/>
									<Error errorName={errors.description} />
								</div>
							</div>
							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductImage")} />
								<div className="col-span-8 sm:col-span-4">
									<Uploader
										product
										folder="product"
										imageUrl={imageUrl}
										setImageUrl={setImageUrl}
									/>
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductSKU")} />
								<div className="col-span-8 sm:col-span-4">
									<InputArea
										register={register}
										label={t("ProductSKU")}
										name="sku"
										type="text"
										placeholder={t("ProductSKU")}
									/>
									<Error errorName={errors.sku} />
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductBarcode")} />
								<div className="col-span-8 sm:col-span-4">
									<InputArea
										register={register}
										label={t("ProductBarcode")}
										name="barcode"
										type="text"
										placeholder={t("ProductBarcode")}
									/>
									<Error errorName={errors.barcode} />
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("Category")} />
								<div className="col-span-8 sm:col-span-4">
									<ParentCategory
										lang={language}
										selectedCategory={selectedCategory}
										setSelectedCategory={setSelectedCategory}
										setDefaultCategory={setDefaultCategory}
									/>
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("DefaultCategory")} />
								<div className="col-span-8 sm:col-span-4">
									<Multiselect
										displayValue="name"
										isObject={true}
										singleSelect={true}
										ref={resetRefTwo}
										hidePlaceholder={true}
										onKeyPressFn={function noRefCheck() {}}
										onRemove={function noRefCheck() {}}
										onSearch={function noRefCheck() {}}
										onSelect={(v) => setDefaultCategory(v)}
										selectedValues={defaultCategory}
										options={selectedCategory}
										placeholder={"Default Category"}></Multiselect>
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label="Product Price" />
								<div className="col-span-8 sm:col-span-4">
									<InputValue
										disabled={isCombination}
										register={register}
										maxValue={2000}
										minValue={1}
										label="Original Price"
										name="originalPrice"
										type="number"
										placeholder="OriginalPrice"
										defaultValue={0.0}
										required={true}
										product
										currency={currency}
									/>
									<Error errorName={errors.originalPrice} />
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("SalePrice")} />
								<div className="col-span-8 sm:col-span-4">
									<InputValue
										disabled={isCombination}
										product
										register={register}
										minValue={0}
										defaultValue={0.0}
										required={true}
										label="Sale price"
										name="price"
										type="number"
										placeholder="Sale price"
										currency={currency}
									/>
									<Error errorName={errors.price} />
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6 relative">
								<LabelArea label={t("ProductQuantity")} />
								<div className="col-span-8 sm:col-span-4">
									<InputValueFive
										required={true}
										disabled={isCombination}
										register={register}
										minValue={0}
										defaultValue={0}
										label="Quantity"
										name="stock"
										type="number"
										placeholder={t("ProductQuantity")}
									/>
									<Error errorName={errors.stock} />
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductSlug")} />
								<div className="col-span-8 sm:col-span-4">
									<Input
										{...register(`slug`, {
											required: "slug is required!",
										})}
										className=" mr-2 p-2"
										name="slug"
										type="text"
										defaultValue={slug}
										placeholder={t("ProductSlug")}
										onBlur={(e) => handleProductSlug(e.target.value)}
									/>
									<Error errorName={errors.slug} />
								</div>
							</div>

							<div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
								<LabelArea label={t("ProductTag")} />
								<div className="col-span-8 sm:col-span-4">
									<ReactTagInput
										placeholder={t("ProductTagPlaseholder")}
										tags={tag}
										onChange={(newTags) => setTag(newTags)}
									/>
								</div>
							</div>
						</div>
					)}

					{tapValue === "Combination" &&
						isCombination &&
						(attribue.length < 1 ? (
							<div
								className="bg-customTeal-100 border border-customTeal-600 rounded-md text-customTeal-900 px-4 py-3 m-4"
								role="alert">
								<div className="flex">
									<div className="py-1">
										<svg
											className="fill-current h-6 w-6 text-customTeal-500 mr-4"
											xmlns="http://www.w3.org/2000/svg"
											viewBox="0 0 20 20">
											<path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z" />
										</svg>
									</div>
									<div>
										<p className="text-sm">
											{t("AddCombinationsDiscription")}{" "}
											<Link to="/attributes" className="font-bold">
												{t("AttributesFeatures")}
											</Link>
											{t("AddCombinationsDiscriptionTwo")}
										</p>
									</div>
								</div>
							</div>
						) : (
							<div className="p-6">
								{/* <h4 className="mb-4 font-semibold text-lg">Variants</h4> */}
								<div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-3 md:gap-3 xl:gap-3 lg:gap-2 mb-3">
									<MultiSelect
										options={attTitle}
										value={attributes}
										onChange={(v) => handleAddAtt(v)}
										labelledBy="Select"
									/>

									{attributes?.map((attribute, i) => (
										<div key={attribute.id}>
											<div className="flex w-full h-10 justify-between font-sans rounded-tl rounded-tr bg-customGray-200 px-4 py-3 text-left text-sm font-normal text-customGray-700 hover:bg-customGray-200">
												{"Select"}
												{showingTranslateValue(attribute?.title)}
											</div>

											<AttributeOptionTwo
												id={i + 1}
												values={values}
												lang={language}
												attributes={attribute}
												setValues={setValues}
											/>
										</div>
									))}
								</div>

								<div className="flex justify-end mb-6">
									{attributes?.length > 0 && (
										<Button
											onClick={handleGenerateCombination}
											type="button"
											className="mx-2">
											<span className="text-xs">{t("GenerateVariants")}</span>
										</Button>
									)}

									{variantTitle.length > 0 && (
										<Button onClick={handleClearVariant} className="mx-2">
											<span className="text-xs">{t("ClearVariants")}</span>
										</Button>
									)}
								</div>
							</div>
						))}

					{isCombination ? (
						<DrawerButton
							id={id}
							save
							title="Product"
							isSubmitting={isSubmitting}
							handleProductTap={handleProductTap}
						/>
					) : (
						<DrawerButton id={id} title="Product" isSubmitting={isSubmitting} />
					)}

					{tapValue === "Combination" && (
						<DrawerButton id={id} title="Product" isSubmitting={isSubmitting} />
					)}
				</form>

				{tapValue === "Combination" &&
					isCombination &&
					variantTitle.length > 0 && (
						<div className="px-6 overflow-x-auto">
							{/* {variants?.length >= 0 && ( */}
							{isCombination && (
								<TableContainer className="md:mb-32 mb-40 rounded-b-lg">
									<Table>
										<TableHeader>
											<tr>
												<TableCell>{t("Image")}</TableCell>
												<TableCell>{t("Combination")}</TableCell>
												<TableCell>{t("Sku")}</TableCell>
												<TableCell>{t("Barcode")}</TableCell>
												<TableCell>{t("Price")}</TableCell>
												<TableCell>{t("SalePrice")}</TableCell>
												<TableCell>{t("QuantityTbl")}</TableCell>
												<TableCell className="text-right">
													{t("Action")}
												</TableCell>
											</tr>
										</TableHeader>

										<AttributeListTable
											lang={language}
											variants={variants}
											setTapValue={setTapValue}
											variantTitle={variantTitle}
											isBulkUpdate={isBulkUpdate}
											handleSkuBarcode={handleSkuBarcode}
											handleEditVariant={handleEditVariant}
											handleRemoveVariant={handleRemoveVariant}
											handleQuantityPrice={handleQuantityPrice}
											handleSelectInlineImage={handleSelectInlineImage}
										/>
									</Table>
								</TableContainer>
							)}
						</div>
					)}
			</Scrollbars>
		</>
	);
};

export default React.memo(ProductDrawer);
