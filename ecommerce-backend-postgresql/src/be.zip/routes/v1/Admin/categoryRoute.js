const express = require('express');
const validate = require('../../../middlewares/validate');
const { adminCategoryController } = require('../../../controllers/Admin');
const { adminCategoryValidation } = require('../../../validations/Admin');
const checkPermission = require('../../../middlewares/checkPermission');

const router = express.Router();

router
	.route('/')
	.get(
		checkPermission('view_category'),
		// validate(adminCategoryValidation.getCategories),
		adminCategoryController.getCategories
	)
	.post(
		checkPermission('create_category'),
		validate(adminCategoryValidation.createCategory),
		adminCategoryController.createCategory
	);
router.route('/similar').get(adminCategoryController.findSimilarCategories);
router.route('/fix-slugs').patch(adminCategoryController.fixSlugsCategories);
router
	.route('/restore-soft-delete')
	.patch(adminCategoryController.restoreSoftDeleteCategories);

router
	.route('/options')
	.get(
		checkPermission('view_category_options'),
		validate(adminCategoryValidation.getCategoriesOptions),
		adminCategoryController.getCategoriesForOptions
	);

router
	.route('/:categoryId')
	.get(
		checkPermission('view_category'),
		validate(adminCategoryValidation.getCategory),
		adminCategoryController.getCategoryById
	)
	.patch(
		checkPermission('update_category'),
		validate(adminCategoryValidation.updateCategory),
		adminCategoryController.updateCategory
	)
	.delete(
		checkPermission('delete_category'),
		validate(adminCategoryValidation.deleteCategory),
		adminCategoryController.softDeleteCategory
	);
router
	.route('/permanent/:categoryId')
	.delete(
		checkPermission('delete_category'),
		validate(adminCategoryValidation.deleteCategory),
		adminCategoryController.permanentDeleteCategory
	);

// routes only for import
router.route('/import').post(adminCategoryController.importCategories);

module.exports = router;
