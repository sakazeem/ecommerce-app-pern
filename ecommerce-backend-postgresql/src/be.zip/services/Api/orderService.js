const httpStatus = require('http-status');
const fs = require('fs');
const {
	orderConfirmationAdminTemplate,
} = require('../../config/emailTemplates/orderConfirmationAdmin');
const {
	orderConfirmationCustomerTemplate,
} = require('../../config/emailTemplates/orderConfirmationUser');
const db = require('../../db/models');
const ApiError = require('../../utils/ApiError');
const { sendEmail } = require('../email.service');
const { addOrUpdateAddress } = require('./appUserService');
const config = require('../../config/config');

async function confirmOrder(req) {
	const { customer, billingAddress, items, summary, userId } = req.body;

	const receiptFile = req.file || null;

	const data = {
		shipping_address: customer.address,
		shipping_city: customer.city,
		shipping_country: customer.country,
		shipping_postal_code: customer.postalCode,
		shipping_apartment: customer.apartment || null,

		billing_address: customer.billingSameAsShipping
			? customer.address
			: billingAddress?.address,
		billing_apartment: customer.billingSameAsShipping
			? customer.apartment
			: billingAddress?.apartment || customer.apartment || null,
		billing_city: customer.billingSameAsShipping
			? customer.city
			: billingAddress?.city || customer.city,
		billing_country: customer.billingSameAsShipping
			? customer.country
			: billingAddress?.country || customer.country,
		billing_postal_code: customer.billingSameAsShipping
			? customer.postalCode
			: billingAddress?.postalCode || customer.postalCode,

		payment_method: customer.paymentMethod,

		order_amount: summary.subtotal,
		shipping: summary.shipping,
		total: summary.total,
	};

	if (userId) {
		data.app_user_id = userId;
		await addOrUpdateAddress(
			{
				address: customer.address,
				apartment: customer.apartment || null,
				city: customer.city,
				country: customer.country,
				postal_code: customer.postalCode,
				type: 'shipping',
			},
			userId
		);
		if (!customer.billingSameAsShipping) {
			await addOrUpdateAddress(
				{
					address: billingAddress.address,
					apartment: billingAddress.apartment || null,
					city: billingAddress.city,
					country: billingAddress.country,
					postal_code: billingAddress.postalCode,
					type: 'billing',
				},
				userId
			);
		}
	} else {
		data.guest_first_name = customer.name;
		data.guest_email = customer.email;
		data.guest_phone = customer.phone;
	}

	const transaction = await db.sequelize.transaction();

	try {
		const createdOrder = await db.order.create(data, {
			transaction,
		});

		// Step 2: Generate unique tracking ID
		const trackingId = 'ORD-' + Date.now() + '-' + createdOrder.id;

		// Step 3: Update order with tracking_id
		createdOrder.tracking_id = trackingId;
		await createdOrder.save({ transaction });

		const orderItemsData = items.map((item) => ({
			order_id: createdOrder.id,
			product_id: item.id,
			product_title: item.title,
			price: item.finalPrice,
			quantity: item.quantity,
			product_variant_id: item.selectedVariant
				? item.selectedVariant.id
				: null,
			sku: item.selectedVariant ? item.selectedVariant.sku : item.sku,
		}));

		await db.order_item.bulkCreate(orderItemsData, {
			transaction,
		});

		const orderId = createdOrder.tracking_id;

		const receiptAttachment = receiptFile
			? [{ filename: receiptFile.originalname, path: receiptFile.path }]
			: [];

		if (customer.email) {
			await sendEmail({
				// to: 'annasahmed1609@gmail.com',
				to: customer.email,
				subject: `Order Confirmation #${orderId}`,
				html: orderConfirmationCustomerTemplate({
					orderId,
					customerName: `${customer.name}`,
					items,
					subtotal: summary.subtotal,
					shipping: summary.shipping,
					total: summary.total,
				}),
				attachments: [],
			});
		}

		await sendEmail({
			// to: 'annasahmed1609@gmail.com',
			// to: 'salmanazeemkhan@gmail.com',
			// to: 'orders@babiesnbaba.com',
			to:
				config.env === 'development'
					? 'annasahmed1609@gmail.com'
					: 'babiesnbaba@gmail.com',
			subject: `New Order #${orderId}`,
			html: orderConfirmationAdminTemplate({
				orderId,
				customer,
				billingAddress,
				items,
				total: summary.total?.toFixed(1),
				shipping: summary.shipping,
				paymentMethod: customer.paymentMethod,
			}),
			attachments: receiptAttachment,
		});

		await transaction.commit();

		if (receiptFile?.path) {
			fs.unlink(receiptFile.path, () => {});
		}

		return createdOrder;
	} catch (error) {
		await transaction.rollback();

		if (receiptFile?.path) {
			fs.unlink(receiptFile.path, () => {});
		}

		console.log(error.message || error);

		throw new ApiError(
			httpStatus.INTERNAL_SERVER_ERROR,
			error.message || 'Order confirmation failed'
		);
	}
}

async function trackOrderByTrackingId(req) {
	const { trackingId } = req.params;
	const order = await db.order.findOne({
		where: {
			tracking_id: trackingId,
		},
		include: [
			{
				model: db.order_item,
				required: false,
			},
		],
	});

	if (!order) {
		throw new ApiError(
			httpStatus.NOT_FOUND,
			'Order not found with this tracking ID'
		);
	}

	return order;
}

async function myOrders(req, userId) {
	if (!userId) {
		throw new ApiError(httpStatus.UNAUTHORIZED, 'Unauthorized');
	}
	return await db.order.findAll({
		where: {
			app_user_id: userId,
		},
		include: [
			{
				model: db.order_item,
				required: false,
				include: [
					{
						model: db.product,
						include: [
							{
								model: db.media,
								required: false,
								as: 'images',
								attributes: ['url', 'title'],
							},
							{
								model: db.media,
								required: false,
								as: 'thumbnailImage',
								attributes: ['url', 'title'],
							},
						],
					},
				],
			},
		],
	});
}
async function getOrderByTrackingId(req, userId) {
	if (!userId) {
		throw new ApiError(httpStatus.UNAUTHORIZED, 'Unauthorized');
	}
	return await db.order.findOne({
		where: {
			app_user_id: userId,
			tracking_id: req.params.trackingId,
		},
		include: [
			{
				model: db.order_item,
				required: false,
				include: [
					{
						model: db.product,
						include: [
							{
								model: db.media,
								required: false,
								as: 'images',
								attributes: ['url', 'title'],
							},
							{
								model: db.media,
								required: false,
								as: 'thumbnailImage',
								attributes: ['url', 'title'],
							},
						],
					},
				],
			},
		],
	});
}

module.exports = {
	confirmOrder,
	trackOrderByTrackingId,
	myOrders,
	getOrderByTrackingId,
};

// confirmOrderPayload
const confirmOrderPayload = {
	customer: {
		email: 'annasahmed1609@gmail.com',
		firstName: 'Annas',
		lastName: 'Ahmed',
		address: 'Bahadurabad, Karachi, Pakistan',
		city: 'Karachi',
		postalCode: '07482',
		country: 'Pakistan',
		phone: '03326556262',
		paymentMethod: 'cod',
		billingSameAsShipping: false,
	},
	billingAddress: {
		country: 'Pakistan',
		firstName: 'Annas',
		lastName: 'Ahmed',
		address: 'Bahadurabad, Karachi, Pakistan',
		city: 'Karachi',
		postalCode: '07482',
		phone: '03326556262',
	},
	items: [
		{
			id: 389,
			title: 'BABY U SHAPE NECK PILLOW FOX ORANGE',
			slug: 'baby-u-shape-neck-pillow-fox-orange',
			thumbnail: '/uploads/baby-u-shape-neck-pillow-fox-orange (1).jpg',
			base_price: 748,
			base_discount_percentage: 20,
			quantity: 4,
			selectedVariant: {
				id: 201,
				sku: 'SKU-1',
				image: null,
				attributes: [],
			},
			unitPrice: 598.4,
			finalPrice: 2393.6,
		},
		{
			id: 307,
			title: 'TU BABY 2PCS PLASTIC APPRIN BIB',
			slug: 'tu-baby-2pcs-plastic-apprin-bib',
			thumbnail: '/uploads/tu-baby-2pcs-plastic-apprin-bib (1).jpg',
			base_price: 415,
			base_discount_percentage: 20,
			quantity: 1,
			selectedVariant: {
				id: 120,
				sku: 'SKU-1',
				image: null,
				attributes: [
					{
						id: 9,
						name: 'gender',
						value: 'Unisex',
					},
				],
			},
			unitPrice: 332,
			finalPrice: 332,
		},
		{
			id: 306,
			title: 'NUS SLEEVE BIB CHINA PRINTED',
			slug: 'nus-sleeve-bib-china-printed',
			thumbnail: '/uploads/nus-sleeve-bib-china-printed (1).jpg',
			base_price: 325,
			base_discount_percentage: 20,
			quantity: 1,
			selectedVariant: {
				id: 119,
				sku: 'SKU-1',
				image: null,
				attributes: [
					{
						id: 9,
						name: 'gender',
						value: 'Unisex',
					},
				],
			},
			unitPrice: 260,
			finalPrice: 260,
		},
	],
	summary: {
		subtotal: 2985.6,
		shipping: 150,
		total: 3135.6,
	},
};
